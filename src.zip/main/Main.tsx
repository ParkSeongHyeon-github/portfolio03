import MainBanner from "./MainBanner";
import "./main.css";

const Main = () => {
    return(
        <>
            <MainBanner />
        </>
    )
}

export default Main;