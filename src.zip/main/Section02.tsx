const Section02 = () => {
    return(
        <div id="Section02">
            
        </div>
    )
}

export default Section02;