import { useState } from 'react';
import { Link } from "react-router-dom";
import { Delete } from "../api/table/table-api";
import ResultMessage from '../components/ResultMessage';
import type { ReservationProps } from "../type/reservation/reservation";
import type { ResultProps } from '../type/result/result-type';
import "../css/view.css"

interface ViewProps {
    viewData : ReservationProps | null,
    table : string,
}

const View = ({viewData, table} : ViewProps) => {
    const [result, setResult] = useState<ResultProps | null>(null);

    const formatPhone = (num: string) => {
        return num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
    };

    const DeleteData = async(id : string) => {
        try{
            const ckDelete = confirm(`해당 게시글을 삭제 하시겠습니까? \n삭제 후 복구는 불가능합니다.`);
            if(ckDelete){
                await Delete('reservation', id);
                setResult({
                    type : "success",
                    message : "게시글이 정상적으로 삭제되었습니다."
                })
            }
        }catch{
            setResult({ 
                type : "error",
                message : "게시글 삭제에 실패했습니다."
            })
        }
    }

    if(!viewData){
        return <div>loading...</div>
    }

    return(
        <div className="view-table">
            {result && <ResultMessage title={"게시글 삭제"} type={result.type} message={result.message} onClose={() => setResult(null)} link={`/reservation/list`} />}
            <div className="title">{viewData.roomSubject}</div>
            <ul className="user">
                <li><span>작성자</span>{viewData.userName}</li>
            </ul>
            {table === 'reservation' && (
            <ul className="info">
                <li><span>이름</span>{viewData.userName}</li>
                <li><span>연락처</span>{formatPhone(viewData.userPhone)}</li>
                <li><span>예약일</span>{viewData.useDate} ~ {viewData.endDate}</li>
                <li><span>성인</span>{viewData.adultCount}</li>
                <li><span>아동</span>{viewData.childCount}</li>
                <li><span>가격</span>{viewData.price.toLocaleString()}원</li>
                <li><span>결제</span>{viewData.orderId ? "결제완료" : "결제대기중"}</li>
            </ul>
            )}
            <div className="content">{viewData.request}</div>
            <div className="btn">
                <Link to="/reservation/list">글 목록</Link>
                <button type='button' onClick={() => DeleteData(viewData.id)} className="delete-btn">글 삭제</button>
            </div>
        </div>
    )
}

export default View;