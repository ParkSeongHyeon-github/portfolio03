import { Link } from 'react-router-dom';

const Header = () => {
    return(
        <header>
            <div id="header-wrap">
                <div className="logo">
                    <Link to="/">SAMPLE</Link>
                </div>
                <nav>
                    <ul>
                        <li><Link to="/room/list">ROOM VIEW</Link></li>
                        <li><Link to="/reservation">RESERVATION</Link></li>
                        <li><Link to="/">COMMUNITY</Link></li>
                    </ul>
                </nav>
            </div>
        </header>
    )
}

export default Header;