import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Main from './main/Main';
import Footer from './components/Footer';
import Login from './member/Login';
import Register from './member/Register';
import RoomWrite from './page/RoomWrite';
import RoomList from './page/RoomList';
import Reservation from './page/Reservation';
import ReservationWrite from './page/ReservationWrite';
import ReservationList from './page/ReservationList';
import ReservationView from './page/ReservationView';
import PaySuccess from './page/PaySuccess';
import PayFail from './page/PayFail';
import './css/default.css';
import './css/common.css';


function App() {
  const [user, setUser] = useState<string | null>(null);
    useEffect(() => {
      const mbLevel = localStorage.getItem("mb_level");
      if(mbLevel){
        setUser(mbLevel)
      }
    }, [])
  return (
    <BrowserRouter>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Main />}></Route>
            <Route path="/login" element={<Login setUser={setUser} />}></Route>
            <Route path="/register" element={<Register />}></Route>
            
            <Route path="/room/write" element={<RoomWrite />}></Route>
            <Route path="/room/write/:room_id" element={<RoomWrite />}></Route>
            <Route path="/room/list" element={<RoomList user={user} />}></Route>

            <Route path="/reservation" element={<Reservation user={user} />}></Route>
            <Route path="/reservation/write/:room_id" element={<ReservationWrite />}></Route>
            <Route path="/reservation/list" element={<ReservationList user={user} />}></Route>
            <Route path="/reservation/view/:res_id" element={<ReservationView />}></Route>

            <Route path="/pay/success" element={<PaySuccess />}></Route>
            <Route path="/pay/fail" element={<PayFail />}></Route>
        </Routes>
      </main>
      <Footer user={user} setUser={setUser}/>
    </BrowserRouter>
  )
}

export default App
